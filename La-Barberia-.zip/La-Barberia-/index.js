function reservar() {
  const hora = document.getElementById("hora").value;
  const lista = document.getElementById("horasDisponibles");
  const opciones = lista.getElementsByTagName("li");

  for (let i = 0; i < opciones.length; i++) {
    if (opciones[i].innerText === hora) {
      lista.removeChild(opciones[i]);
      document.getElementById("mensaje").innerText = `✅ Has reservado la hora: ${hora}`;
      document.getElementById("mensaje").style.color = "green";
      return;
    }
  }
  document.getElementById("mensaje").innerText = "❌ Hora no disponible.";
  document.getElementById("mensaje").style.color = "red";
}
